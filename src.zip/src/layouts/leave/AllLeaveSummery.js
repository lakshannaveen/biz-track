import React from "react";

export default function AllLeaveSummery() {
  return <div>AllLeaveSummery</div>;
}
