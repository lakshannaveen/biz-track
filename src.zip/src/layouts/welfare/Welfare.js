import React from "react";

export default function Welfare() {
  return <div>Welfare</div>;
}
